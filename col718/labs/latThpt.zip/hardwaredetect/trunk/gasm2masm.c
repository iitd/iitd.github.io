/*
 * =====================================================================================
 *
 *       Filename:  gasm2masm.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/11/2010 08:47:59 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  djx.zhenghua@gmail.com , 
 *        Company:  
 *
 * =====================================================================================
 */

typedef struct {
	char opctype;
	char op[24];
	char opc1[64];
	char opc2[64];
	char opc3[64];
	char opc4[64];
} Instruction_t;

typedef struct{
	char n1;
	char n2;
	char n3;
	char reserved;
	char r[32][64];

} gasmTailer_t;

void transInstruction(Instruction_t* pgasm, Instruction_t* pmasm)
{

}

char*  getgInstruction(char* p, Instruction_t* pgasm)
{

}

char* readGasmHeader(char* p)
{

}

int readGasmTailer(char* p)
{
}

char* gasm2masm(char* src, char* endp)
{

}
